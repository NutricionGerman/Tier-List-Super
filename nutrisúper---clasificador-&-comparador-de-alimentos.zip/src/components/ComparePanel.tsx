import React, { useState } from 'react';
import { Product, NutrientKey } from '../types';
import { NUTRIENTS_METADATA } from '../data';
import { TierBadge } from './TierBadge';
import { Scale, Check, AlertCircle, RefreshCw, Sparkles, TrendingUp, DollarSign } from 'lucide-react';

interface ComparePanelProps {
  selectedProducts: Product[];
  onRemoveProduct: (product: Product) => void;
  onClearAll: () => void;
}

export const ComparePanel: React.FC<ComparePanelProps> = ({
  selectedProducts,
  onRemoveProduct,
  onClearAll
}) => {
  const [activeNutrient, setActiveNutrient] = useState<NutrientKey>('sodium');

  if (selectedProducts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center h-full select-none bg-[#FCFAF7]">
        <div className="w-16 h-16 bg-white border border-editorial-border rounded-none flex items-center justify-center mb-4">
          <Scale className="w-6 h-6 text-editorial-muted stroke-[1.5]" />
        </div>
        <h3 className="font-serif text-sm font-bold italic text-editorial-text">Comparador Inteligente</h3>
        <p className="text-[11px] text-editorial-muted max-w-[240px] mt-2 leading-relaxed font-serif italic">
          Selecciona 2 quesos del listado tocando el botón <strong>"Comparar"</strong> para ver sus diferencias nutricionales en detalle.
        </p>
      </div>
    );
  }

  if (selectedProducts.length === 1) {
    const prod = selectedProducts[0];
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center h-full select-none bg-[#FCFAF7]">
        <div className="relative mb-4">
          <div className="w-14 h-14 bg-white border border-editorial-border rounded-none flex items-center justify-center">
            <Scale className="w-6 h-6 text-editorial-gold animate-pulse" />
          </div>
          <span className="absolute -top-1 -right-1 bg-editorial-gold text-white text-[9px] font-sans font-bold px-1.5 py-0.5 rounded-none shadow-sm">
            1/2
          </span>
        </div>
        <h3 className="font-sans text-[10px] font-bold tracking-widest text-editorial-muted uppercase">Has seleccionado:</h3>
        <p className="text-sm font-serif font-bold italic text-editorial-text mt-1">{prod.brand} — {prod.name}</p>
        <p className="text-[11px] text-editorial-muted max-w-[240px] mt-2.5 leading-relaxed font-serif italic">
          Selecciona otro producto de la lista para iniciar la comparación cara a cara.
        </p>
        <button
          onClick={() => onRemoveProduct(prod)}
          className="mt-4 px-4 py-2 bg-white hover:bg-stone-100 text-editorial-text border border-editorial-border rounded-none text-[10px] font-sans font-bold tracking-widest uppercase transition-colors"
        >
          Quitar Selección
        </button>
      </div>
    );
  }

  // We have exactly 2 or more products (we will take the first 2)
  const [p1, p2] = selectedProducts;
  const currentMetadata = NUTRIENTS_METADATA.find(n => n.key === activeNutrient) || NUTRIENTS_METADATA[0];

  const val1 = p1[activeNutrient];
  const val2 = p2[activeNutrient];

  const hasND = val1 === 'N/D' || val2 === 'N/D';
  const num1 = typeof val1 === 'number' ? val1 : 0;
  const num2 = typeof val2 === 'number' ? val2 : 0;

  // Determine winner for current nutrient
  const getWinner = () => {
    if (hasND) return null;
    if (num1 === num2) return 'tie';
    
    if (currentMetadata.betterDirection === 'lower') {
      return num1 < num2 ? 'p1' : 'p2';
    } else {
      return num1 > num2 ? 'p1' : 'p2';
    }
  };

  const winner = getWinner();

  // Algorithmically compute nutritionist's feedback comparing these exact 2 items!
  const getComparisonVerdict = () => {
    if (p1.id === p2.id) return 'Estás comparando el mismo queso.';

    let verdict = '';
    
    // 1. Analyze Sodium differences (very relevant for grocery cheesemakers)
    const sodDiff = Math.abs(p1.sodium - p2.sodium);
    const protDiff = Math.abs(p1.proteins - p2.proteins);
    const fatDiff = Math.abs(p1.saturatedFats - p2.saturatedFats);

    if (activeNutrient === 'sodium') {
      if (sodDiff > 300) {
        const lowerSod = p1.sodium < p2.sodium ? p1 : p2;
        const higherSod = p1.sodium < p2.sodium ? p2 : p1;
        verdict = `¡Diferencia crítica de sodio! **${lowerSod.brand} (${lowerSod.sodium}mg)** contiene casi **10 veces menos sal** que **${higherSod.brand} (${higherSod.sodium}mg)**. Para proteger la salud cardiovascular e hipertensión, elige indiscutiblemente **${lowerSod.brand}**.`;
      } else {
        const lowerSod = p1.sodium < p2.sodium ? p1 : p2;
        verdict = `En sodio, ambas opciones están en rangos intermedios o similares, pero **${lowerSod.brand} (${lowerSod.sodium}mg)** sigue siendo marginalmente mejor.`;
      }
    } else if (activeNutrient === 'saturatedFats') {
      if (fatDiff > 5) {
        const lowerFat = p1.saturatedFats < p2.saturatedFats ? p1 : p2;
        const higherFat = p1.saturatedFats < p2.saturatedFats ? p2 : p1;
        verdict = `Vigilancia en grasas: **${lowerFat.brand} (${lowerFat.saturatedFats}g)** es mucho más liviano y amigable con el colesterol que **${higherFat.brand} (${higherFat.saturatedFats}g)**, el cual posee grasas en exceso. Opta por **${lowerFat.brand}**.`;
      } else {
        const lowerFat = p1.saturatedFats < p2.saturatedFats ? p1 : p2;
        verdict = `Ambos quesos tienen perfiles de grasas saturadas razonablemente parecidos, con una pequeña ventaja para **${lowerFat.brand}**.`;
      }
    } else if (activeNutrient === 'proteins') {
      if (protDiff > 10) {
        const higherProt = p1.proteins > p2.proteins ? p1 : p2;
        const lowerProt = p1.proteins > p2.proteins ? p2 : p1;
        verdict = `¡Brecha proteica de peso! **${higherProt.brand}** te brinda **${higherProt.proteins}g de proteína**, un aporte extraordinario para saciedad y masa muscular, en contraste con los tímidos **${lowerProt.proteins}g** de **${lowerProt.brand}**.`;
      } else {
        const higherProt = p1.proteins > p2.proteins ? p1 : p2;
        verdict = `Aporte proteico equivalente para ambos. **${higherProt.brand}** lidera apenas con **${higherProt.proteins}g**.`;
      }
    } else if (activeNutrient === 'pricePerKg') {
      if (p1.pricePerKg === 'N/D' || p2.pricePerKg === 'N/D') {
        verdict = 'Falta el precio por kilogramo de uno de los productos para hacer un veredicto de costo exacto. Consulta en góndola.';
      } else {
        const p1Price = p1.pricePerKg as number;
        const p2Price = p2.pricePerKg as number;
        const priceDiff = Math.abs(p1Price - p2Price);
        const lowerPrice = p1Price < p2Price ? p1 : p2;
        const higherPrice = p1Price < p2Price ? p2 : p1;
        if (priceDiff > 5000) {
          verdict = `¡Atención al bolsillo! **${lowerPrice.brand}** cuesta **$${lowerPrice.pricePerKg.toLocaleString('es-AR')}/kg**, lo que representa un ahorro masivo de **$${priceDiff.toLocaleString('es-AR')} por kilo** frente a **${higherPrice.brand}**, sin comprometer severamente tu salud.`;
        } else {
          verdict = `Diferencia de precio menor. **${lowerPrice.brand}** es la opción más económica a **$${lowerPrice.pricePerKg.toLocaleString('es-AR')}/kg**.`;
        }
      }
    } else {
      // General verdict based on overall Tier
      const p1TierOrder = ['S', 'A', 'B', 'C', 'D', 'F'].indexOf(p1.tier);
      const p2TierOrder = ['S', 'A', 'B', 'C', 'D', 'F'].indexOf(p2.tier);
      if (p1TierOrder < p2TierOrder) {
        verdict = `Evaluación integral: **${p1.brand} ${p1.name}** es una opción nutricional superior (${p1.tier}-Tier) comparado con **${p2.brand} ${p2.name}** (${p2.tier}-Tier), principalmente por su menor contenido graso o de sodio.`;
      } else if (p1TierOrder > p2TierOrder) {
        verdict = `Evaluación integral: **${p2.brand} ${p2.name}** es una opción nutricional superior (${p2.tier}-Tier) comparado con **${p1.brand} ${p1.name}** (${p1.tier}-Tier).`;
      } else {
        verdict = `Ambos quesos están en la misma categoría de recomendación (${p1.tier}-Tier). Elige según el precio o tu preferencia de sabor.`;
      }
    }

    return verdict;
  };

  // Percent calculation for the progress compare bars
  const maxVal = Math.max(num1, num2, 1);
  const percent1 = hasND ? 0 : Math.round((num1 / maxVal) * 100);
  const percent2 = hasND ? 0 : Math.round((num2 / maxVal) * 100);

  return (
    <div className="flex flex-col h-full bg-[#FCFAF7] select-none font-sans">
      
      {/* Compare Sticky Sub-Header */}
      <div className="bg-white px-5 py-4 border-b border-editorial-border flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-editorial-text" />
          <h2 className="font-serif text-sm font-bold italic text-editorial-text">Comparación Cara a Cara</h2>
        </div>
        <button
          onClick={onClearAll}
          className="text-[10px] font-sans font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 px-2.5 py-1.5 rounded-none uppercase tracking-widest transition-colors"
        >
          Limpiar Todo
        </button>
      </div>

      {/* Two Compared Products Small Cards */}
      <div className="grid grid-cols-2 gap-3 p-4 bg-white border-b border-editorial-border shrink-0">
        {/* Product 1 */}
        <div className="relative bg-[#F4F1EA] p-3 rounded-none border border-editorial-border flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex flex-col pr-1">
              <span className="text-[8px] font-sans font-bold text-editorial-muted uppercase tracking-wider">{p1.brand}</span>
              <h4 className="text-xs font-serif font-bold italic text-editorial-text line-clamp-1 leading-snug mt-0.5">{p1.name}</h4>
            </div>
            <TierBadge tier={p1.tier} size="sm" />
          </div>
          <button
            onClick={() => onRemoveProduct(p1)}
            className="text-[8px] font-sans font-bold text-editorial-muted hover:text-red-600 text-left mt-2.5 transition-colors uppercase tracking-widest"
          >
            ❌ Quitar
          </button>
        </div>

        {/* Product 2 */}
        <div className="relative bg-[#F4F1EA] p-3 rounded-none border border-editorial-border flex flex-col justify-between">
          <div className="flex items-start justify-between">
            <div className="flex flex-col pr-1">
              <span className="text-[8px] font-sans font-bold text-editorial-muted uppercase tracking-wider">{p2.brand}</span>
              <h4 className="text-xs font-serif font-bold italic text-editorial-text line-clamp-1 leading-snug mt-0.5">{p2.name}</h4>
            </div>
            <TierBadge tier={p2.tier} size="sm" />
          </div>
          <button
            onClick={() => onRemoveProduct(p2)}
            className="text-[8px] font-sans font-bold text-editorial-muted hover:text-red-600 text-left mt-2.5 transition-colors uppercase tracking-widest"
          >
            ❌ Quitar
          </button>
        </div>
      </div>

      {/* Metric/Nutrient Picker Carousel */}
      <div className="p-3 bg-[#F5F2EB] overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0 border-b border-editorial-border">
        {NUTRIENTS_METADATA.map((nut) => (
          <button
            key={nut.key}
            onClick={() => setActiveNutrient(nut.key)}
            className={`px-3.5 py-1.5 rounded-none text-[10px] font-sans font-bold uppercase tracking-wider shrink-0 transition-all border ${
              activeNutrient === nut.key
                ? 'bg-editorial-text text-white border-editorial-text shadow-sm'
                : 'bg-white text-editorial-muted hover:bg-[#F4F1EA] border-editorial-border'
            }`}
          >
            {nut.label}
          </button>
        ))}
      </div>

      {/* Visual Comparison Area */}
      <div className="flex-1 p-5 overflow-y-auto space-y-6">
        
        {/* Metric Card Details */}
        <div className="bg-white p-4.5 rounded-none border border-editorial-border space-y-4">
          <div className="text-center">
            <h3 className="font-serif text-sm font-bold italic text-editorial-text">
              Comparando {currentMetadata.label}
            </h3>
            <p className="text-[10px] text-editorial-muted mt-1 max-w-[280px] mx-auto leading-relaxed font-serif italic">
              {currentMetadata.description}
            </p>
          </div>

          {/* Progress Comparative Bars */}
          <div className="space-y-4 pt-2">
            
            {/* Product 1 Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-sans">
                <span className="font-semibold text-editorial-text line-clamp-1 max-w-[150px]">
                  {p1.brand} {p1.name}
                </span>
                <span className={`font-serif italic font-bold ${winner === 'p1' ? 'text-editorial-gold' : 'text-editorial-muted'}`}>
                  {p1[activeNutrient] === 'N/D' ? 'N/D' : `${p1[activeNutrient]} ${currentMetadata.unit}`}
                  {winner === 'p1' && ' 👑'}
                </span>
              </div>
              <div className="h-3 w-full bg-[#E5E1D8] rounded-none overflow-hidden flex">
                {val1 !== 'N/D' ? (
                  <div
                    className={`h-full rounded-none transition-all duration-500 ${
                      winner === 'p1' ? 'bg-editorial-gold' : 'bg-editorial-muted'
                    }`}
                    style={{ width: `${percent1}%` }}
                  />
                ) : (
                  <div className="w-full bg-[#E5E1D8] text-[10px] text-editorial-muted italic flex items-center px-2 font-serif">No Disponible</div>
                )}
              </div>
            </div>

            {/* Product 2 Bar */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs font-sans">
                <span className="font-semibold text-editorial-text line-clamp-1 max-w-[150px]">
                  {p2.brand} {p2.name}
                </span>
                <span className={`font-serif italic font-bold ${winner === 'p2' ? 'text-editorial-gold' : 'text-editorial-muted'}`}>
                  {p2[activeNutrient] === 'N/D' ? 'N/D' : `${p2[activeNutrient]} ${currentMetadata.unit}`}
                  {winner === 'p2' && ' 👑'}
                </span>
              </div>
              <div className="h-3 w-full bg-[#E5E1D8] rounded-none overflow-hidden flex">
                {val2 !== 'N/D' ? (
                  <div
                    className={`h-full rounded-none transition-all duration-500 ${
                      winner === 'p2' ? 'bg-editorial-gold' : 'bg-editorial-muted'
                    }`}
                    style={{ width: `${percent2}%` }}
                  />
                ) : (
                  <div className="w-full bg-[#E5E1D8] text-[10px] text-editorial-muted italic flex items-center px-2 font-serif">No Disponible</div>
                )}
              </div>
            </div>

          </div>

          {/* Metric Verdict Legend */}
          {!hasND && (
            <div className="text-center border-t border-editorial-border pt-3 text-[10px] font-sans font-bold uppercase tracking-wider text-editorial-muted flex items-center justify-center gap-1.5">
              {winner === 'tie' ? (
                <span>⚖️ Empate técnico en esta categoría.</span>
              ) : (
                <>
                  <Check className="w-3.5 h-3.5 text-editorial-gold" />
                  <span>
                    El líder en <strong>{currentMetadata.label}</strong> es{' '}
                    <strong>{winner === 'p1' ? p1.brand : p2.brand}</strong>.
                  </span>
                </>
              )}
            </div>
          )}
        </div>

        {/* Nutritionist's Custom Smart Summary */}
        <div className="bg-[#2D2A26] text-white p-5 rounded-none border border-editorial-border relative overflow-hidden shadow-sm">
          <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
            <Sparkles className="w-32 h-32 text-white" />
          </div>

          <div className="flex items-center gap-2 mb-3 text-editorial-gold">
            <Sparkles className="w-4 h-4 text-editorial-gold fill-editorial-gold" />
            <span className="text-[10px] font-sans font-bold tracking-[0.18em] uppercase">
              Veredicto de Germán Auad
            </span>
          </div>

          {/* Format the verdict with bold markers */}
          <p className="text-xs text-stone-200 leading-relaxed font-serif italic">
            {getComparisonVerdict().split('**').map((text, idx) => (
              idx % 2 === 1 ? <strong key={idx} className="text-editorial-gold font-bold not-italic font-sans text-[11px] tracking-wide uppercase">{text}</strong> : text
            ))}
          </p>
        </div>

        {/* Supermarket Pro-Tips Mini Card */}
        <div className="bg-[#F4F1EA] p-4 rounded-none border border-editorial-border flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-editorial-gold shrink-0 mt-0.5" />
          <div className="flex flex-col gap-0.5">
            <span className="text-[10px] font-sans font-bold text-editorial-text uppercase tracking-wider">Consejo del Supermercado</span>
            <span className="text-[10px] text-editorial-muted leading-relaxed font-serif italic">
              Recuerda siempre verificar la tabla por cada 100g. En Argentina, la porción declarada suele ser de 30g, lo que a veces disfraza el exceso real de sodio y grasas saturadas.
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};
