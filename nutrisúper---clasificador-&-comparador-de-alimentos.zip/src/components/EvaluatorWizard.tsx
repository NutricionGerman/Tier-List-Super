import React, { useState } from 'react';
import { Product } from '../types';
import { PRODUCTS } from '../data';
import { TierBadge } from './TierBadge';
import { ShieldAlert, Award, TrendingDown, HelpCircle, DollarSign, Leaf, ArrowRight, RotateCcw, MapPin, Sparkles } from 'lucide-react';

interface EvaluatorWizardProps {
  onViewProduct: (product: Product) => void;
}

export const EvaluatorWizard: React.FC<EvaluatorWizardProps> = ({ onViewProduct }) => {
  const [step, setStep] = useState<number>(1);
  const [priority, setPriority] = useState<string | null>(null);

  const OPTIONS = [
    {
      id: 'sodium',
      label: 'Cuidar la presión / Menos Sodio',
      icon: ShieldAlert,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-100 hover:bg-emerald-100/50',
      description: 'Prioriza quesos con bajísimo contenido de sal para hipertensión.'
    },
    {
      id: 'protein',
      label: 'Ganar músculo / Más Proteínas',
      icon: Award,
      color: 'text-blue-600 bg-blue-50 border-blue-100 hover:bg-blue-100/50',
      description: 'Prioriza quesos con excelente perfil proteico por porción.'
    },
    {
      id: 'calories',
      label: 'Bajar de peso / Menos Calorías',
      icon: TrendingDown,
      color: 'text-amber-600 bg-amber-50 border-amber-100 hover:bg-amber-100/50',
      description: 'Busca las opciones más ligeras y con menor densidad energética.'
    },
    {
      id: 'vegan',
      label: 'Evitar lácteos / Opción Vegana',
      icon: Leaf,
      color: 'text-green-600 bg-green-50 border-green-100 hover:bg-green-100/50',
      description: 'Alternativas hechas a base de plantas y semillas.'
    },
    {
      id: 'budget',
      label: 'Cuidar el bolsillo / Más Barato',
      icon: DollarSign,
      color: 'text-slate-700 bg-slate-50 border-slate-100 hover:bg-slate-100/50',
      description: 'Excelente relación calidad-precio por kilo de queso.'
    }
  ];

  const handleSelectPriority = (id: string) => {
    setPriority(id);
    setStep(2);
  };

  const resetWizard = () => {
    setPriority(null);
    setStep(1);
  };

  // Recommender logic based on priority selection with rigorous scientific corrections
  const getRecommendation = (): { product: Product; note: string } => {
    if (priority === 'sodium') {
      const prod = PRODUCTS.find(p => p.id === 'tregar-por-salut-light-sin-sal')!;
      return {
        product: prod,
        note: 'El exceso de sodio no solo eleva la presión arterial; daña, inflama y rigidiza las arterias de forma directa e inmediata (en solo 30 minutos tras la ingesta) a través del estrés oxidativo y la supresión de enzimas protectoras, incluso en personas con presión arterial completamente normal. Esta opción de Tregar tiene apenas 37mg de sodio.'
      };
    }
    if (priority === 'protein') {
      // Clean Protein approach - recommending Tregar Por Salut Light Sin Sal (29g protein, only 37mg sodium, no inflammatory vascular overload)
      const prod = PRODUCTS.find(p => p.id === 'tregar-por-salut-light-sin-sal')!;
      return {
        product: prod,
        note: 'La proteína extra láctea concentrada (caseína) no genera masa muscular por sí sola si no hay entrenamiento estructurado de fuerza; además, hiperactiva la vía mTORC1 y eleva la hormona IGF-1 acelerando el envejecimiento celular, induciendo hiperfiltración renal aguda. Recomiendo un enfoque de "Proteína Limpia" con esta opción de Tregar, aportando unos excelentes 29g de proteína con solo 37mg de sodio y sin la sobrecarga inflamatoria vascular de otros quesos altos en sal.'
      };
    }
    if (priority === 'calories') {
      // Recommend Port Salut Sin Sal Light (La Serenísima) (217 kcal, only 38mg sodium) to avoid sodium sabotaging metabolism
      const prod = PRODUCTS.find(p => p.id === 'la-serenisima-port-salut-sin-sal-light')!;
      return {
        product: prod,
        note: 'El queso carece de fibra para dar saciedad prolongada mediante el "freno ileal" (solo presente en vegetales y legumbres), y sus grasas saturadas se almacenan inmediatamente reduciendo la sensibilidad a la insulina. Además, el sodio es un factor de riesgo independiente de obesidad. Recomiendo esta opción con solo 38mg de sodio para evitar el sabotaje metabólico de la sal.'
      };
    }
    if (priority === 'vegan') {
      const prod = PRODUCTS.find(p => p.id === 'felices-las-vacas-muzzalmendra-vegano')!;
      return {
        product: prod,
        note: 'El beneficio real de evitar lácteos no radica solo en la lactosa, sino en eludir su "equipaje biológico" nocivo: galactosa (azúcar lácteo que acelera el envejecimiento), Neu5Gc (azúcar animal proinflamatorio), hormonas bovinas y grasas trans rumiantes. No te preocupes por la proteína: los adultos ya ingieren de media el doble de la requerida y la proteína vegetal es completa, limpia y libre de toxicidad vascular.'
      };
    }
    // budget priority
    // Recommend Por Salut Light Sin Sal (Tregar) because its price is practically equal to the salted version,
    // and represents a far superior vascular health investment. Eliminate "sodium is fine if pressure is good".
    const prod = PRODUCTS.find(p => p.id === 'tregar-por-salut-light-sin-sal')!;
    return {
      product: prod,
      note: 'A un costo similar al de alternativas con sal, el Por Salut Light Sin Sal de Tregar representa la inversión de salud vascular más costo-eficiente para la canasta familiar. Evita el sodio añadido; el exceso de sal daña y rigidiza las arterias de manera inmediata y silenciosa, sin importar si sufres de presión arterial o no.'
    };
  };

  const recommendation = priority ? getRecommendation() : null;

  return (
    <div className="bg-white rounded-none border border-editorial-border p-5 shadow-sm select-none font-sans">
      
      {/* Header section */}
      <div className="flex items-start gap-2.5 mb-4">
        <div className="w-8 h-8 bg-[#F4F1EA] border border-editorial-border rounded-none flex items-center justify-center shrink-0">
          <HelpCircle className="w-4 h-4 text-editorial-gold" />
        </div>
        <div>
          <h3 className="font-serif text-sm font-bold italic text-editorial-text">
            Asistente Rápido de Góndola
          </h3>
          <p className="text-[10px] text-editorial-muted mt-0.5 font-serif italic">
            ¿No sabes cuál llevar hoy? Deja que Germán te recomiende el ideal en 2 pasos.
          </p>
        </div>
      </div>

      {step === 1 ? (
        <div className="space-y-2.5">
          <span className="text-[9px] font-sans font-bold text-editorial-muted uppercase tracking-[0.12em]">
            Paso 1: ¿Cuál es tu objetivo de salud hoy?
          </span>

          <div className="space-y-2">
            {OPTIONS.map((opt) => {
              const Icon = opt.icon;
              return (
                <button
                  key={opt.id}
                  onClick={() => handleSelectPriority(opt.id)}
                  className="w-full text-left p-3 rounded-none border border-editorial-border hover:border-editorial-text bg-[#FCFAF7] flex items-center gap-3 transition-all cursor-pointer group"
                >
                  <div className="p-2 bg-white border border-editorial-border rounded-none shrink-0 text-editorial-muted group-hover:text-editorial-gold transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-sans font-bold text-editorial-text uppercase tracking-wider group-hover:text-black leading-snug">{opt.label}</span>
                    <span className="text-[9.5px] text-editorial-muted mt-0.5 leading-tight font-serif italic">{opt.description}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        recommendation && (
          <div className="space-y-4 animate-fade-in">
            <span className="text-[9px] font-sans font-bold text-editorial-muted uppercase tracking-[0.12em]">
              Paso 2: La recomendación de Germán
            </span>

            {/* Recommended Product Visual Card */}
            <div
              onClick={() => onViewProduct(recommendation.product)}
              className="p-4 bg-[#FCFAF7] rounded-none border border-editorial-border flex items-center justify-between cursor-pointer hover:bg-[#F4F1EA] transition-colors"
            >
              <div className="flex items-center gap-3">
                <TierBadge tier={recommendation.product.tier} size="sm" />
                <div className="flex flex-col pr-1">
                  <span className="text-[9px] font-sans font-bold text-editorial-muted uppercase tracking-wider">{recommendation.product.brand}</span>
                  <h4 className="text-xs font-serif font-black italic text-editorial-text leading-tight mt-0.5">{recommendation.product.name}</h4>
                  <div className="flex items-center gap-1.5 mt-1.5">
                    {recommendation.product.pricePerKg !== 'N/D' && (
                      <span className="text-[10px] font-sans font-bold text-editorial-text">
                        ${recommendation.product.pricePerKg.toLocaleString('es-AR')}/kg
                      </span>
                    )}
                    {recommendation.product.recommendedSupermarkets.length > 0 && (
                      <span className="text-[9px] text-emerald-800 font-sans font-semibold tracking-wide flex items-center gap-0.5">
                        <MapPin className="w-2.5 h-2.5 text-editorial-gold" />
                        {recommendation.product.recommendedSupermarkets[0]}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-editorial-muted shrink-0" />
            </div>

            {/* Nutritionist's Note */}
            <div className="bg-[#2D2A26] text-white p-4 rounded-none border border-editorial-border relative overflow-hidden">
              <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none">
                <Sparkles className="w-16 h-16 text-white" />
              </div>
              <div className="flex items-center gap-1.5 text-editorial-gold text-[10px] font-sans font-bold uppercase tracking-widest mb-1.5">
                <Sparkles className="w-3.5 h-3.5 text-editorial-gold fill-editorial-gold" />
                <span>¿Por qué este queso?</span>
              </div>
              <p className="text-xs text-stone-200 italic font-serif leading-relaxed">
                "{recommendation.note}"
              </p>
            </div>

            {/* Reset Controller */}
            <button
              onClick={resetWizard}
              className="w-full py-2.5 bg-[#F4F1EA] hover:bg-[#E5E1D8] text-editorial-text border border-editorial-border text-[10px] font-sans font-bold rounded-none uppercase tracking-widest flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Volver a empezar</span>
            </button>
          </div>
        )
      )}

    </div>
  );
};
