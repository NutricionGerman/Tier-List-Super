import { Product, Category, NutrientMetadata } from './types';

export const CATEGORIES: Category[] = [
  {
    id: 'quesos-blandos',
    name: 'Quesos Blandos',
    icon: '🧀',
    description: 'Quesos de pasta blanda, ideales para untar, derretir o comer en ensaladas.'
  },
  {
    id: 'yogures',
    name: 'Yogures Descremados',
    icon: '🥛',
    description: 'Yogures enteros y descremados analizados por su azúcar y proteínas.',
    isComingSoon: true
  },
  {
    id: 'panes',
    name: 'Panes de Molde',
    icon: '🍞',
    description: 'Panes lactales e integrales, evaluados por su fibra y conservantes.',
    isComingSoon: true
  },
  {
    id: 'galletas',
    name: 'Galletitas de Cereal',
    icon: '🍪',
    description: 'Galletitas dulces y saladas. Analizando harinas refinadas y grasas trans.',
    isComingSoon: true
  }
];

export const NUTRIENTS_METADATA: NutrientMetadata[] = [
  {
    key: 'calories',
    label: 'Calorías',
    unit: 'kcal',
    betterDirection: 'lower',
    description: 'Aporte energético por cada 100g de producto.'
  },
  {
    key: 'proteins',
    label: 'Proteínas',
    unit: 'g',
    betterDirection: 'higher',
    description: 'Nutriente esencial para la musculatura y saciedad.'
  },
  {
    key: 'totalFats',
    label: 'Grasas Totales',
    unit: 'g',
    betterDirection: 'lower',
    description: 'Total de grasas (saludables y saturadas) por cada 100g.'
  },
  {
    key: 'saturatedFats',
    label: 'Grasas Sat.',
    unit: 'g',
    betterDirection: 'lower',
    description: 'Grasas que conviene limitar para cuidar la salud cardiovascular.'
  },
  {
    key: 'sodium',
    label: 'Sodio',
    unit: 'mg',
    betterDirection: 'lower',
    description: 'Mineral crítico para la presión arterial. Menos es mejor.'
  },
  {
    key: 'calcium',
    label: 'Calcio',
    unit: 'mg',
    betterDirection: 'higher',
    description: 'Mineral vital para la salud ósea y dental.'
  },
  {
    key: 'pricePerKg',
    label: 'Precio por Kg',
    unit: 'ARS',
    betterDirection: 'lower',
    description: 'Costo por kilogramo para evaluar la relación calidad/precio.'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'tregar-por-salut-light-sin-sal',
    puesto: 1,
    name: 'Por Salut Light Sin Sal',
    brand: 'Tregar',
    calories: 243,
    proteins: 29,
    totalFats: 13,
    saturatedFats: 7.0,
    sodium: 37,
    calcium: 800,
    pricePerKg: 16985,
    recommendedSupermarkets: ['Carrefour', 'Comodín'],
    tier: 'S',
    badge: '🥇 1er Puesto - Súper Recomendado',
    nutritionistVerdict: '¡La opción estrella! Prácticamente libre de sodio (solo 37mg), altísimo en proteínas y con un aporte graso muy controlado. Excelente para hipertensos y descenso de peso.',
    imageUrl: 'https://images.unsplash.com/photo-1528256846579-03b0c47ae3db?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3' // Abstract premium cheese representation
  },
  {
    id: 'felices-las-vacas-muzzalmendra-vegano',
    puesto: 2,
    name: 'Muzzalmendra (Vegano)',
    brand: 'Felices Las Vacas',
    calories: 273,
    proteins: 2,
    totalFats: 22,
    saturatedFats: 6.0,
    sodium: 533,
    calcium: 'N/D',
    pricePerKg: 15020,
    recommendedSupermarkets: ['Carrefour (Tienda Digital)'],
    tier: 'A',
    badge: '🥈 2do Puesto - Mejor Plant-Based',
    nutritionistVerdict: 'Es la mejor opción si llevas una dieta libre de lácteos o vegana. Es bajo en grasas saturadas (6g), pero ten en cuenta que casi no aporta proteínas (solo 2g) y el sodio es elevado.',
    imageUrl: 'https://images.unsplash.com/photo-1552763426-441aee5e6f7d?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-port-salut-light',
    puesto: 3,
    name: 'Port Salut Light',
    brand: 'La Serenísima',
    calories: 218,
    proteins: 27,
    totalFats: 12,
    saturatedFats: 7.2,
    sodium: 430,
    calcium: 932,
    pricePerKg: 15260,
    recommendedSupermarkets: ['Comodín'],
    tier: 'B',
    badge: '🥉 3er Puesto - Opción Equilibrada',
    nutritionistVerdict: 'Muy buen balance de proteínas (27g) y excelente cantidad de calcio (932mg, de los más altos). El sodio es intermedio, siendo una opción cotidiana muy sólida para la población general.',
    imageUrl: 'https://images.unsplash.com/photo-1486299267070-83823f5448dd?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-cremon-light',
    puesto: 4,
    name: 'Cremón Light',
    brand: 'La Serenísima',
    calories: 236,
    proteins: 21,
    totalFats: 17,
    saturatedFats: 11.0,
    sodium: 340,
    calcium: 714,
    pricePerKg: 18190,
    recommendedSupermarkets: ['Comodín'],
    tier: 'C',
    badge: '🏅 4to Puesto - Aceptable',
    nutritionistVerdict: 'Su textura cremosa es excelente, pero ten cuidado: aunque dice "Light", posee 11g de grasas saturadas, sensiblemente mayor que las opciones superiores. Consumo moderado.',
    imageUrl: 'https://images.unsplash.com/photo-1596450514946-a329737922d2?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'tregar-por-salut-dietetico-con-sal',
    puesto: 5,
    name: 'Por Salut Dietético con Sal',
    brand: 'Tregar',
    calories: 233,
    proteins: 29,
    totalFats: 13,
    saturatedFats: 7.0,
    sodium: 550,
    calcium: 800,
    pricePerKg: 14499,
    recommendedSupermarkets: ['Carrefour', 'Comodín'],
    tier: 'C',
    badge: '🏅 5to Puesto - Buena Proteína',
    nutritionistVerdict: 'Tiene un contenido de proteínas espectacular (29g) y un precio muy competitivo. No obstante, el sodio sube a 550mg. Es una gran alternativa económica si no tienes restricción de sal.',
    imageUrl: 'https://images.unsplash.com/photo-1589881133595-a3c085cb1493?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-port-salut-sin-sal-light',
    puesto: 6,
    name: 'Port Salut Sin Sal Light',
    brand: 'La Serenísima',
    calories: 217,
    proteins: 27,
    totalFats: 12,
    saturatedFats: 7.2,
    sodium: 38,
    calcium: 932,
    pricePerKg: 25550,
    recommendedSupermarkets: ['La Anónima'],
    tier: 'C',
    badge: '🏅 6to Puesto - Premium Costoso',
    nutritionistVerdict: 'Nutricionalmente impecable (solo 38mg de sodio y excelente calcio/proteína). Sin embargo, su precio es sumamente elevado en comparación con Tregar. Si el dinero no es traba, es un S-Tier.',
    imageUrl: 'https://images.unsplash.com/photo-1624806992066-5ffcf7ca186b?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-queso-protein',
    puesto: 7,
    name: 'Queso Protein',
    brand: 'La Serenísima',
    calories: 191,
    proteins: 30,
    totalFats: 7.5,
    saturatedFats: 5.0,
    sodium: 597,
    calcium: 955,
    pricePerKg: 25690,
    recommendedSupermarkets: ['Comodín', 'La Serenísima'],
    tier: 'D',
    badge: '🚨 7mo Puesto - Alerta Sodio y Costo',
    nutritionistVerdict: 'Es el más bajo en calorías y grasas de todos, y el más alto en proteínas (30g). Lamentablemente, posee un exceso notable de sodio (597mg) y un precio altísimo. Consumir de manera planificada.',
    imageUrl: 'https://images.unsplash.com/photo-1528256846579-03b0c47ae3db?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-cremon-cremoso',
    puesto: 8,
    name: 'Cremón Cremoso',
    brand: 'La Serenísima',
    calories: 290,
    proteins: 18,
    totalFats: 24,
    saturatedFats: 15.0,
    sodium: 330,
    calcium: 642,
    pricePerKg: 18550,
    recommendedSupermarkets: ['Comodín'],
    tier: 'F',
    badge: '🚫 8vo Puesto - No Recomendado Diario',
    nutritionistVerdict: 'Porcentaje graso elevado (24g de grasas totales y 15g saturadas). No es adecuado para el consumo de todos los días, ya que aporta muchas calorías vacías de grasas saturadas.',
    imageUrl: 'https://images.unsplash.com/photo-1596450514946-a329737922d2?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'la-serenisima-port-salut-clasico',
    puesto: 9,
    name: 'Port Salut Clásico',
    brand: 'La Serenísima',
    calories: 305,
    proteins: 20,
    totalFats: 25,
    saturatedFats: 15.0,
    sodium: 370,
    calcium: 807,
    pricePerKg: 'N/D',
    recommendedSupermarkets: [],
    tier: 'F',
    badge: '🚫 9no Puesto - No Recomendado',
    nutritionistVerdict: 'El queso clásico tiene un tenor graso elevado (15g saturadas) que perjudica tu perfil lipídico si se consume en demasía. Reemplaza siempre por su equivalente Light de la misma marca.',
    imageUrl: 'https://images.unsplash.com/photo-1486299267070-83823f5448dd?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'tregar-por-salut',
    puesto: 10,
    name: 'Por Salut Clásico',
    brand: 'Tregar',
    calories: 323,
    proteins: 20,
    totalFats: 27,
    saturatedFats: 16.0,
    sodium: 437,
    calcium: 653,
    pricePerKg: 'N/D',
    recommendedSupermarkets: [],
    tier: 'F',
    badge: '🚫 10mo Puesto - No Recomendado',
    nutritionistVerdict: 'Muy alto en calorías (323) y grasas saturadas (16g) comparado con su versión Light. No se justifica nutricionalmente existiendo la alternativa Light Sin Sal de la misma firma.',
    imageUrl: 'https://images.unsplash.com/photo-1589881133595-a3c085cb1493?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: 'tregar-cremoso',
    puesto: 11,
    name: 'Cremoso Clásico',
    brand: 'Tregar',
    calories: 337,
    proteins: 19,
    totalFats: 29,
    saturatedFats: 17.0,
    sodium: 483,
    calcium: 647,
    pricePerKg: 'N/D',
    recommendedSupermarkets: [],
    tier: 'F',
    badge: '🚫 11er Puesto - Evitar en Dieta Habitual',
    nutritionistVerdict: 'El menos saludable de la comparativa. Es el que tiene más calorías (337) y más grasas saturadas (17g) de todo el catálogo, además de un sodio considerable. Reservar únicamente para ocasiones especiales.',
    imageUrl: 'https://images.unsplash.com/photo-1624806992066-5ffcf7ca186b?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  }
];

export const TIER_DETAILS = {
  S: { name: 'S-Tier', color: 'from-emerald-500 to-teal-600', text: 'text-emerald-700 bg-emerald-50 border-emerald-200', desc: 'Opción Excelente: Bajo en sodio, baja grasa, alto en proteína.' },
  A: { name: 'A-Tier', color: 'from-green-400 to-emerald-500', text: 'text-green-700 bg-green-50 border-green-200', desc: 'Muy Recomendable: Buena calidad, ideal si buscas alternativas (vegano/bajos).' },
  B: { name: 'B-Tier', color: 'from-blue-400 to-indigo-500', text: 'text-blue-700 bg-blue-50 border-blue-200', desc: 'Opción Equilibrada: Bueno para uso general diario.' },
  C: { name: 'C-Tier', color: 'from-amber-400 to-orange-500', text: 'text-amber-700 bg-amber-50 border-amber-200', desc: 'Consumo Moderado: Detalles a vigilar (sodio elevado o grasa intermedia).' },
  D: { name: 'D-Tier', color: 'from-orange-500 to-red-400', text: 'text-orange-700 bg-orange-50 border-orange-200', desc: 'Consumo Ocasional: Vigilar por alto contenido de sodio o precio excesivo.' },
  F: { name: 'F-Tier', color: 'from-red-500 to-rose-600', text: 'text-rose-700 bg-rose-50 border-rose-200', desc: 'Evitar Diario: Demasiado graso o calórico. Preferir sustitutos light.' }
};
